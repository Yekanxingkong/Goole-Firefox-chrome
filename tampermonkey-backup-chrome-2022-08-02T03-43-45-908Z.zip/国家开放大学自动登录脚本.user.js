// ==UserScript==
// @name         国家开放大学自动登录脚本
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       夜看星空
// @match        http://passport.ouchn.cn/Account/Login*
// @icon         https://www.google.com/s2/favicons?domain=45.165
// @grant        none
// ==/UserScript==
(function() {
    'use strict';
    let SignName = function(){
    document.getElementById('username').value="2032001453819";//替换用户名
    document.getElementById('password').value='Ouchn19980825';//替换密码
    var isChecked = document.getElementById("RememberLogin").checked;
    if (isChecked == true){
        console.log('已经完成了保持登陆');
    }else{
        document.getElementById("RememberLogin").checked = true;
    }
    document.getElementById('loginbth').click();
    }
    setTimeout(SignName(),"3000")
    // Your code here...
})();