// ==UserScript==
// @name         允许学习通后台播放
// @namespace    http://tampermonkey.net/
// @version      0.3
// @description  去除监听器
// @author       LikeJson<
// @match        https://mooc1.chaoxing.com/mycourse/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=chaoxing.com
// @grant        none
// @license GNU AGPLv3
// ==/UserScript==

(function() {
    'use strict';

    window.onload = function() {
        let eventList = ["mouseout", "mousemove", "mousedown", "mouseover", "mouseup", "dragover", "touchmove"];

        for (let type of eventList) {
            window.addEventListener(type, function(event) {
                event.stopPropagation();
            }, true);
        }
    }
})();