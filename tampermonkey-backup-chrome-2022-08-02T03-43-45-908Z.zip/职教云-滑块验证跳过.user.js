// ==UserScript==
// @name 职教云|滑块验证跳过
// @namespace https://act_meteor.rth1.me/
// @version 1.2
// @description 职教云滑块验证跳过
// @author ACT_Meteor
// @match https://zjy2.icve.com.cn/study/process/process.html*
// @match https://zjy2.icve.com.cn/common/directory/directory.html*
// @icon https://zjy2.icve.com.cn/common/images/logo.png
// @grant none
// ==/UserScript==










var FindSpeed = 2000; //响应速度。数值越小，弹出页面时反应速度越快，建议不要小于1000。单位毫秒ms。   注：1秒=1000ms

var SlidingSpeed = 20; //滑动速度。建议不要小于5，数值过小会验证失败。单位毫秒ms。   注：1秒=1000ms





















var Finder
(function() {
	statr()
	function statr() {
		Finder = setInterval(function() {
			var tap = document.getElementById('nc_1__scale_text')
			var tapc = tap.firstChild.nodeName
			var taptext = tap.firstChild.innerText
			if (tapc == 'SPAN' && taptext == '请按住滑块，拖动到最右边') {
				console.log('找到滑块，开始滑动');
				slide('nc_1_n1z')
			}
		}, FindSpeed)
	}
})();
function slide(id) {
	clearInterval(Finder);
	var slider = document.getElementById(id),
		container = slider.parentNode;
	var rect = slider.getBoundingClientRect(),
		x0 = rect.x || rect.left,
		y0 = rect.y || rect.top,
		w = container.getBoundingClientRect().width,
		dx = 0,
		dy = 0;
	var mousedown = document.createEvent("MouseEvents");
	mousedown.initMouseEvent("mousedown", true, true, window, 0,x0, y0, x0, y0, false, false, false, false, 0, null);
	slider.dispatchEvent(mousedown);
	var intervaltimer = setInterval(function() {
		var mousemove = document.createEvent("MouseEvents");
		var _x = x0 + dx;
		var _y = y0 + dy;
		mousemove.initMouseEvent("mousemove", true, true, window, 0,_x, _y, _x, _y, false, false, false, false, 0, null);
		slider.dispatchEvent(mousemove);
		slider.dispatchEvent(mousemove);
		if (_x - x0 >= w) {
			clearInterval(intervaltimer);
			var mouseup = document.createEvent("MouseEvents");
			mouseup.initMouseEvent("mouseup", true, true, window, 0,_x, _y, _x, _y, false, false, false, false, 0, null);
			slider.dispatchEvent(mouseup);
			setTimeout(function() {
				console.log('拖动结束执行逻辑');
			}, 1000);
		} else {
			dx += parseInt(Math.random() * (209 - 199) + 199) / 33;
			console.log(x0, y0, _x, _y, dx);
		}
	}, SlidingSpeed);
}